
function Topic() {
    return (
        <h2>Topic page</h2>
    )
}
export default Topic;