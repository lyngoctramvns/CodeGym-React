import ContainerF from '../Components/ContainerF';
import Home from "../Components/Home";
import Topic from '../Components/Topic';

const routers = [
    {
      path : "/product",
      element : <ContainerF></ContainerF>,
      name : "Product"
    },
    {
      path : "/",
      element : <Home></Home>,
      name : "Home"
    },
    {
      path : "/topic",
      element : <Topic></Topic>,
      name :"Topic"
    }
]
export default routers;